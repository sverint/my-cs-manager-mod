# iamgri mod for Esports Manager 2026 - Features

Everything the mod changes, compared to the original game.

It comes in two parts. **The skin** is always on. **The Increased Realism Pack** is your choice on the first start
(see the Installation Guide). With the skin only, the game plays exactly as it came.

## Part 1 - The skin

### A new look for the whole game
- Every screen rebuilt in one style: flat panels, clear tables, one accent colour. Press F1 in the game to pick the background and accent colours.
- Montserrat for the game's text.
- Every team name that opens a team, and every player or staff name that opens a person, is underlined and clickable - in tables, brackets, emails and pages.
- EMTV is called HLTV everywhere, with HLTV's own logo on its emails.
- Fits every screen shape: 16:9, 16:10, 4:3 / 5:4 and ultrawide (21:9). The menus and pages fill the whole window,
  the broadcast HUDs and the map veto fit narrow screens and spread over wide ones, and resizing the window redraws
  them.
- Flags and photos drawn smooth at any size; every flag in one shape.
- A team without a logo shows a shield with its first letter.
- The mod's pages follow the game's language: **Russian, German, Spanish and Brazilian Portuguese** (other languages
  show them in English). Names, CS terms and the broadcast HUDs stay as they are.

### Main menu and new career
- A new main menu, Settings and Workshop.
- A loading screen of its own while a save loads.
- The whole new-career flow rebuilt: save slot, your manager (photo, name, profile), an existing club or your own, the team list (with VRS places and stars), your own club's identity, and the agreement - an existing club taken over gets a proper management agreement.
- A database you upload (.emdb) is remembered between game starts, instead of going back to the default every time.
- The mod brings its own database: real teams, players and staff, with Valve's ranking points (rosters as of
  October 2026). Take it on the first start or on the Database page; it is loaded again each time the game starts.
- Runs on EM26 ModKit, next to other ModKit mods; nothing to run to install - unzip into the game's folder. The edition
  and the database are asked on the first start, and the edition under the version number changes them later.

### Home
- Your upcoming events and matches, the VRS ranking (with a link to the full ranking), your squad, your season with recent results, and the top players.

### Your club and people
- Club page with tabs: Info, Roster, Matches, Events, Transfers, Achievements, Stats. "Create academy" right there when you can make one.
- Player page: attributes, roles, contract, and statistics with tabs (events, matches with K-D, ADR, KAST and rating per series). The club, reputation and market value are links.
- Staff page: contract with a wage comparison, transfer history, and buy / sell / remove from list.
- Squad, Staff, Training (squad training, map practice, scrims), Scouting (filters, watchlist) and Talk screens rebuilt.
- Scouting: saved filters picked from a drop-down, a tick for only the players an offer of yours could reach, each player's best role and second role, Add to watchlist from his Scouting tab; up to three assignments at once, or an ongoing one that reports every two weeks.
- Staff search by region, role and ability (from one number of stars to another).

### Scrims
- Teams ranked near yours invite you to scrims on some of your free days. An email tells you who; accept in Training > Scrims. A scrim is played like a match and gives practice on its map. (The original game's scrims are drawn on its own Home screen, which the skin replaces - so the mod draws them itself.)

### Transfers, sponsors, money
- Transfers: world and club transfer tables with search (any name or club, across years), filters and sortable columns.
- My transfers shows where each of your deals stands: offer sent, negotiating, rejected, then the player's contract -
  negotiating, offered, terms agreed - and agreed, with the day he joins.
- The offer pop-ups (contract, transfer, termination) restyled, with a year jump in the transfer-date calendar.
- Sponsors: the list with a sponsor's details beside it, the sponsored teams as links, the 3D jersey. A reward item in an objective opens it in the shop - or in your basecamp, if you already have it.
- Finances page, with the monthly report.
- Automatic budget allocation: money that comes in is split between wages, running costs and transfers on its own. Move it yourself on the Finances page whenever you like (or turn it off in the settings file).
- Your CFO keeps every budget out of the red: when one drops below zero, he moves money over from Transfers.
- Shop and Basecamp as a table with details beside it; the shop filters by rating.

### Mail
- A compact list with a wide reading pane, search, "mark all read" and "delete all". Emails that need an answer are marked.
- Designed emails: the analyst's pre-match report (the opponent's last 3 months, map by map), the transfer digest as a table, the playoff bracket, the tournament results with the MVP card, map pool changes, the monthly finance report, and transfer / loan offers with the deal terms inside the email (accept, change and send, or reject there).
- Offer emails as one card the width of the email: the player with his wage, contract end and value, your scout's advice beside them, his answer in a speech bubble (counter-offer, accepted, refused) instead of the letter, an orange dot by every term he changed - answered right there.
- Contract reminders: an email about each player (main team and academy) and each member of staff 6, 3 and 1 month before their contract ends, with the contract inside - **Offer a new contract**, **Let it expire** or **Ignore**. Continue waits for an answer.
- A season review from the board when a season ends (the first Major's end, and 31 December): your VRS line through the season, trophies and top-8 finishes, your best win and worst loss, the squad's ratings with the player of the season, and every event with its placing and prize money - for your academy too.
- Academy news: when an event your academy played ends with it in the top 8, the tournament's results email comes for it too.

### Tournaments and statistics
- Tournaments calendar with tier filters; each event's bracket and standings - every played match opens its match page, every team its page, and a Watch button where a match can be watched.
- Statistics: teams and players, with HS % and more.
- CSTV: a page of today's matches (filters by tier, watch any of them).
- Event MVP and EVPs, as HLTV names them: when a Major, tier-1 or tier-2 event ends, its Statistics tab shows its MVP and the EVPs (the other standouts of the playoff teams - as many as HLTV gives such an event), the results email lists them, and a player's Trophies tab keeps his.

### Matches
- A pre-match page and a post-match page: maps with scores and halves, the veto, the match MVP, and full match stats for every map.
- The map veto as a page: both teams' map pools (played, win rate, CT/T, picks and bans first, your practice level), the picks and bans as map cards with the starting sides.
- Quick match, from the veto page or the in-match menu: the rest of the match played out at once by the game's own engine.
- Broadcast HUDs in the organisers' own style for watched matches:
  - **PGL** - PGL events and their qualifiers
  - **ESL** - ESL Pro League
  - **BLAST** - every BLAST event (Open, Rivals, Bounty)
  - **IEM** - every IEM event (Majors included)

  Each with its scoreboard, the series, player cards (photo, HP, armour, weapon, grenades in price order, money, kills this round), the kill feed, the bomb and the defuse, and (PGL) a TAB board with every round. Other events keep the game's own HUD.

### Speed
- The day ticks faster (the pause between days is shorter).
- Heavy screens open faster; the transfer engine's daily checks are faster.
- The day-end autosave is spaced out and runs in the background (settings in `BepInEx\config\com.gri.emskin.cfg`).

## Part 2 - The Increased Realism Pack

### A real-world season
- About 300 events in 2026 and about 800 a year from 2027, in four tiers, instead of the game's fixed slots: the real tier-1 circuit (IEM, PGL, BLAST, ESL Pro League, Esports World Cup, StarSeries and more) and real tier 2, 3 and 4 events.
- Two Majors a year (June and December), hosted by organisers that change every year, on different continents.
- Events change city every year where the real ones do; their logos are included.
- Real formats: Swiss stages, GSL groups, double elimination, play-ins - as the real events play them.
- Online events play two rounds a day (you can play two matches that day); several online events can run at once.
- Tier 2-4 events are regional (Europe, the Americas, Asia) where the real ones are; LANs are open to all.
- Closed qualifiers for tier-1 events: their winners go to the event.
- Each save gets its own seasons; the next season is built in late October, so its invites go out on time.
- Real prize money: every event pays its real prize pool to as many places as it really pays, and each prize is split between the club and the players (the club also takes a cut of the players' part).
- 2027 follows the announced real tier-1 calendar (the FiRe Major in Buenos Aires, the Perfect World Major in Shanghai); later seasons repeat it with the dates moving a little.
- From 2027, tier 3 and tier 4 are drawn each season from real series - which events run, how often, and their dates change from year to year.

### Invites and registration
- Tier-1 events and Majors invite teams 60 days before, by that day's VRS; a Major places teams in its stages by VRS.
- Tier 2-4 events: you register. You get registration emails for the events of your level (your VRS place); any other event can be joined from the tournaments calendar. Applications are decided when registration closes, by ranking.
- Teams invited to two events at once choose one, the way real teams would (prize, level, home region).
- Teams sometimes withdraw before an event and are replaced; you get an email for the events you play. You can withdraw too.
- Academies enter events on their own ranking - yours signs itself up for events of its level.
- Tier-3 events are open to the VRS top 200. A mid-ranked team is also invited to smaller tier-3 events when it has nothing else on.
- Every team with a full roster gets to play: the smallest events go round the whole field.
- Tier 2-4 fields are drawn, leaning to the stronger teams of the level, so teams don't meet the same opponents week after week.

### Valve's ranking (VRS)
- Teams are ranked by Valve's Regional Standings - the real model - worked out every Monday from the last 12 months of results, instead of the game's own points. A new career starts from the database's standings.
- The Majors' places go by region, as Valve's do.
- The points belong to a team's core, as in Valve's model: sign three players of a team's five and you take its points along; a new team - your own signings, or a team that changed three of its five - starts at the bottom and earns its points match by match.
- The pre-match page shows what a win and a loss do to your points ("Win +12 · Loss -18 VRS"); a played series shows its VRS change, both teams' for other teams' matches.

### Maps
- Teams are better on some maps than others: map ratings from 6 months of results and map practice (the AI teams practise their maps too).
- The map veto is played out properly: each team bans the opponent's strong maps and picks its own.

### Simulated matches like real CS
Every simulated match - the AI's and the ones you quick-play - fitted on two seasons of real results and player stats
(2025-26) and HLTV's 2026 ratings:
- **Who wins:** fitted on 20,721 real maps of 2025-26 - a team's five's stars at the roles they play, each at his condition that day; an IGL who can't call at the team's level costs a lot; chemistry (new signings cost a little for a few weeks), one language or a mixed five, an AWPer and a support of the team's level; form that moves by results against what was expected; a little rust after a break. The VRS ranks teams but no longer decides their matches. Upsets come as often as in real CS, teams have good and bad days so a series swings as a whole, a team back from a long break is a little rusty, and a new team of strong players is about as strong as its players. The pre-match win chance shows the same model.
- **The best players top the tables:** the stars of the best teams lead a season, as on HLTV - before, a good player beside weak teammates out-rated them. The very best get a bigger share of their team's kills; AWPers rate a little higher, IGLs lower.
- **The rating on HLTV's scale:** an average map is 1.00, a season's ratings spread like HLTV's, bad games count as much as good ones, and players have good and bad days (a 2.0+ map about once in 80). Ratings are coloured as on HLTV: green from 1.05, red from 0.95.
- **Rounds like real CS:** multi-kill rounds, clutches won, trades and headshots as often as in real matches.
- **Quick-match stats like real CS:** each player's numbers show his role - the AWPer, the entry, the IGL - and a player can have a hot or a cold event.
- Transfer prices are measured against the new rating, so they stay as they were.

### Players
- **Every player rated again** from real HLTV results against the best teams: stars, roles and attributes follow real stats.
- **Player Paths:** every player has his own development path, new in every career - playing time, his club and his coaches bend it.
- **Scouting like Football Manager:** stars are your scout's estimate and can be wrong; send a scout to watch a player to see him in full.
- **Scouting grades weigh the whole report:** a player's grade comes from his stars, his pros and cons and his potential, against your players of his role; your own players are your scout's read too, and a new signing takes about a month to be fully known.
- **Less predictable players:** form comes in spells, a star can have a bad event, and some players are better or worse than their attributes.
- **Growth like Football Manager:** every player has a potential for the career and grows toward it slowly - mostly by playing (a bench player slower, a free agent hardly), helped by his productivity and coaches - peaking around 24, the best talents earlier. From about 28 he declines (aim first; never tactics, leadership, grenades, creativity or teamwork), and a player with a good mind grows into a leader - a fading star can become an IGL.
- **Illness and injuries, reworked:** instead of the game's random sickness, players catch real things - a cold, the flu, a sore wrist - each with its own length and a hit that fades as they recover. Low Immunity means getting ill more often. A rare injury rules a player out for weeks: you see it before the match and play your sixth, an academy player or a stand-in. The physio emails you; staff get ill quietly. AI players too.
- **Roles:** every player plays the role he's best at; a great caller is worth having again even if his aim isn't, and an AI club gives the IGL job to its best caller.
- **Training by role:** the staff's Auto-schedule drills the skills a player's role relies on, where he has the most room (an AWPer his AWP and reaction, an IGL his calling) - AI clubs train the same way.
- **Potential never below ability:** a player still growing shows at least his current stars; once he stops, his potential is his ability.
- **New players by nation:** each nation's talent from the database (Russia, Denmark, Ukraine, Poland, Sweden, France make the most); 400 regens a year, more of them with real potential. Retirement like real pros: weak players stop sooner, stars play on, long-time free agents retire.
- **Big-game players:** Stress Resistance from real playoff and final records (5 to 20); in playoffs and finals a composed player takes more of his team's kills, and composure grows with tier-1 playoff experience. Loyalty decides how readily a player leaves; Morale and Conflictiveness touch his team's swings and chemistry.
- **Staff from the players' countries:** generated coaches and other staff come from the same countries as the players,
  with real names from there.
- **Reputation:** one number from 0 to 100 earned over a career - Majors, titles, MVPs, EVPs, Top 20 places (every player starts with his real career behind him) and how big he is now. It adds to his wage and value.

### Contracts and transfers
- **Values from what the market sees:** a player's value and wage follow his last months' form, the level of the events he plays (a great tier-3 season is not a tier-1 one) and his reputation - not his hidden ability. An unknown youngster is cheap until he proves himself; a young player with a good record costs more than an older one with the same; a hot run lifts the price for a while. Clubs price players through their own scouts, so a club with poor scouts can sell a talent cheap or ask too much.
- **AI clubs bid for your players:** a club that needs one of your players makes you an offer by email, and pays over his value when it really needs him.
- **Contracts by the lawyer:** how long a contract a club can offer depends on its lawyer - half a year without one, up to five years with a good one. AI clubs the same.
- **Contract talks like real CS:** a player weighs your club against his level - asks more, or says no and tells you why; your scout tells you first. Lowball him and he walks out. Longer contracts cost a little less a month. Your players refuse to extend or ask to leave only for lasting reasons.
- **Transfer talks like real CS:** no round limit - a club meets you halfway on each counter until its final offer, as far as it wants the player and can afford; turn the final one down and it walks away for two weeks.
- **Bonuses and wage clauses:** add up to three of each to a contract offer (a VRS place, reaching a Major or its playoffs, a tier-1 or Major win, HLTV's Top 20, MVPs, EVPs) - paid out of the wage budget when earned, each with an email. A young talent above your club wants a release clause, and a bigger club may pay it.
- **Players make demands:** about a third of the players you sign or renew want something in the contract, by who they are - a star a Top 20 or MVP bonus, a player at a big club a trophy bonus, a young talent or a disloyal player a release clause. Your scout tells you first, your offer comes with it filled in, and without it he asks for more wage; only a demand too big to skip makes him walk. AI clubs' contracts get the same.
- **Release clauses on AI contracts:** offer a player's clause and his club accepts at once. Loyal players turn down clubs paying their clause while your team does well; disloyal ones want a clause in their contract.
- **Pre-contracts:** in a contract's last three months - no fee, he joins the day it ends. AI clubs sign them too, your players included.
- **Buy another club's core:** a Buy the core button on every club's page - pick three to five of its starters and
  make one offer for them. The club answers by email in a few days: a top club asks more, and offering under its price
  is a gamble. Confirm, and they join your five on two-year contracts while your starters move to the bench; their
  sponsors stay with their club.
- **Stand-ins:** a free agent for a month, or another club's spare player on a month's loan, from his Contract tab - for a sick player, a short squad or a trial.

### AI clubs
- **Squads built for a reason:** a club judges its players' last half year and replaces the one who isn't delivering, and players choose where they go - a bigger club, more money, or a strong project. Clubs loan out only academy players and don't sell a player in his first half year.
- **Money like real clubs:** income by ranking, fame and who backs them (Falcons, Vitality, NAVI, Spirit and others get an owner's money); wages and signings within it, and a club in the red sells.
- **Squads built like real teams:** every club picks an IGL, an AWPer and a support of its level and buys what it lacks; benched players are listed or loaned, a player too good for his club is sold before he walks, academies promote and loan their prospects, rich clubs buy a rising team's core, a fallen big club rebuilds at the level its money pays for.
- **AI clubs scout before they buy:** a club judges other clubs' players through its own scouts - one with poor scouts sometimes signs a weaker player than it thought, and replaces him at its next review.
- **Clubs buy from each other at every level:** a club signs a starter from any club, stronger or weaker, when he is an upgrade, the price is paid and he wants to come - the best players move between top teams.
- **An older player in AI academies:** an academy may have one player over 21 - often an experienced IGL to lead the young ones, or a benched player keeping in shape.
- **Teams keep who they are:** national teams (Spirit, The MongolZ, TYLOO, Legacy...) sign their own bloc first, international rosters prefer their core's players; top-20 teams keep their three best unless the offer is big.
- **Club reputation:** every club has a reputation from its history, its results and where it stands now. A famous name signs players its ranking alone couldn't and gets more backing; players turn down clubs far below them.
- **A living world:** old famous clubs stay gone until one makes a comeback, and new young players often start out at small clubs.
- **A team short of five** during or before an event signs a stand-in or promotes from its academy instead of withdrawing.
- **iamgri Team:** a Russian club of five cat players and ten cat staff - nobody can sign them and the club never sells, so the five play together until they retire, all at once. Take the job yourself and you can buy and sell as anywhere. Untick iamgri Team in Settings and new careers start without it.

### HLTV's awards
- **Event MVP:** the best-rated player of the two teams in the final, as HLTV picks it - at Majors, tier 1 and tier 2 only (no MVP for qualifiers and smaller events).
- **HLTV's Top 20 of the year, the HLTV way:** by how a player did at the Majors, tier-1 and tier-2 events against the best teams (each map weighted by the opponent's VRS place that week), then by his MVPs and EVPs and his team's results. Revealed a place a day from 1 January.
- **HLTV Awards of the year:** from 21 January, an email from HLTV a day names the year's best Opener, Closer, Support and AWPer, the IGL (judged on winning), the Rookie of the year and the Coach of the year - each on a card with the stats that matter for the role. A player's Trophies tab lists his awards.

### And more
- The match MVP is the player with the highest rating (a tie goes to the winning team).
- The analyst's pre-match report comes for your next match only, the following one after that match is played.
- Loans: recall a player you loaned out once a month has passed; your club can loan out any number of players.
- Transfers agreed with a club that is playing an event go through on their date instead of waiting for the event to end.
- Tournaments the game used to leave unfinished at the year change are closed properly.

## Credits

- Mod by **Gri (iamgri)**.
- Mod loader: **EM26 ModKit** by NeverFall & Xleb1g (a BepInEx 6 build for this game, LGPL-2.1), installed separately.
- Tournament logos belong to their organisers; they are included only so the game can show them (taken from
  Liquipedia).
- The mod's database is Gri's own, built on the Steam Workshop's **World Updated** database, used with its creator's
  permission, and kept up to date from **Liquipedia** (rosters, staff, birth dates - liquipedia.net, CC-BY-SA 3.0),
  **bo3.gg** (match statistics) and **Valve's Regional Standings**.
- Needed with it (see the Installation Guide): the Workshop picture pack **EM26 Face Megapack**, and recommended
  **EM26 Logo Megapack** - by their own creators. The photo pack carries the player and staff pictures of **Custom Images**
  and **Real images** (by their own creators) that the Face Megapack doesn't have.
- Fonts, all under the SIL Open Font License 1.1 (https://openfontlicense.org): **Montserrat** (The Montserrat Project
  Authors), **Roboto Condensed** (The Roboto Project Authors), **Sofia Sans Extra Condensed** (The Sofia Sans Project
  Authors), **Bebas Kai** (Dharma Type), **Barlow Condensed** (The Barlow Project Authors), **Plus Jakarta Sans** (The
  Plus Jakarta Sans Project Authors), **Oswald** (The Oswald Project Authors), **Anton** (The Anton Project Authors), **Saira** and **Saira
  Condensed** (The Saira Project Authors), **Rajdhani** (Indian Type Foundry).
  Their licences are in
  `BepInEx\emskin\fonts`.

News, help, bug reports and ideas: the mod's Discord, **iamgri mod EM26** - https://discord.gg/PcXxHFB8zR

The mod never connects to the internet.
