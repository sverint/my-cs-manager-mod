# iamgri mod for Esports Manager 2026 - Installation Guide

For the **Steam version of Esports Manager 2026** (build 25257320), on **Windows**.
The mod runs on **EM26 ModKit**, the mod loader most Esports Manager 2026 mods use. This zip has the mod, its
tournament logos and its database. What the mod changes is in **iamgri mod - Features.md**.

## 1. Install EM26 ModKit (once)

Skip this if you already have **EM26 ModKit 2.2 or newer** - other mods may have asked for it already.

1. Download it from Nexus Mods: https://www.nexusmods.com/esportsmanager2026/mods/66 (Files tab).
2. Install it as its page says: close the game, unzip it into the game's folder, start the game once from Steam.
   The first start takes 60-90 seconds while ModKit sets itself up (a black console window shows meanwhile).

Coming from **iamgri mod 2.0.0 or older**, which brought its own loader: before unzipping ModKit, delete
`winhttp.dll`, `doorstop_config.ini`, `.doorstop_version`, the `dotnet` folder and, inside `BepInEx`, the `core`,
`interop` and `cache` folders. Keep the rest of `BepInEx` - your settings are in `BepInEx\config`.

## 2. Install the mod

1. Close the game.
2. Open the game's folder: in Steam, right-click Esports Manager 2026 > **Manage > Browse local files**.
3. Unzip this zip **into that folder**: open the zip, select everything in it (Ctrl+A) and drag it into the game's
   folder. (Or right-click the zip > **Extract All** > **Browse**, and pick the game's folder.)
   If Windows asks to replace files, choose **Replace**. If it asks for administrator permission, click **Continue**.
4. Check: `BepInEx\plugins\EMSkin.dll` is in the game's folder.
5. Start the game from Steam as usual.

## 3. The first start

The main menu opens with a box that asks two things:

- **Edition**
  - **Skin + Increased Realism Pack:** the new look plus the real-world Counter-Strike season and the other gameplay changes.
  - **Skin only:** the new look; the game plays exactly as it came.
- **Use the iamgri mod database:** real teams, players and staff, with Valve's ranking points, for your new careers.
  On by default. The mod loads it again each time the game starts, so it doesn't get lost. With the Increased Realism
  Pack it is always on - the pack is made on it; to play on another database, choose Skin only.

Click **Done**. If you picked the other edition, the box offers to close the game: start it again from Steam and the
new edition is on.

To change either later, click the edition under the version number at the top right of the main menu.
With Skin only, the database can also be taken on the main menu's **Database** page (**Use the mod's database**);
**Use the default** there goes back to the game's own.

The Increased Realism Pack's calendar is best chosen before a new career. A career already running keeps
this season's events and gets the real calendar from the next season. A new database is used by new careers only.

## 4. Photos and logos

**The Workshop packs.** The mod brings the tournament logos and the database. For player photos and team logos, add
these free picture packs from the Steam Workshop (other creators' work):

| What | Workshop item |
|---|---|
| Player and staff photos | **EM26 Face Megapack** - https://steamcommunity.com/sharedfiles/filedetails/?id=3790789526 |
| Team and sponsor logos | **EM26 Logo Megapack** - https://steamcommunity.com/sharedfiles/filedetails/?id=3790790555 |

1. Open each link and click **Subscribe** (or in the game: main menu > **Workshop** > Browse, search the name, Subscribe).
2. Restart the game. The pictures are used from then on.
3. Subscribed to **Custom Images** or **Real images**? Unsubscribe from them: the photo pack carries what is needed from
   them, and the game reads them before the Face Megapack, so their older photos would cover its newer ones.

**The photo pack** - a separate download on the mod's Nexus page (`iamgri-mod-photos-<number>.zip`):

- a player who moves wears his new club's kit in his photo;
- new players get real-looking faces that fit their country;
- many real players who had no photo get one.

It needs the **EM26 Face Megapack** above: without it, the players whose photos come from that pack keep their old
club's kit. Install it like the mod: close the game, unzip it into the game's folder (choose **Replace** if asked),
start the game. Download it again only when its number changes - the mod's updates don't need it.
To keep every photo as it is: open `BepInEx\config\com.gri.emskin.cfg` with Notepad and under `[Photos]` set
`KitFollowsClub = false`.

## 5. Updating

Unzip the new version into the game's folder the same way, over the old one, and choose **Replace**.
Your settings and your saves stay.

## 6. Uninstall

Delete `BepInEx\plugins\EMSkin.dll` and the `BepInEx\emskin` folder from the game's folder, and the two
`iamgri mod - ...md` files. ModKit and your other mods stay.

Your saves are not touched, and keep working without the mod. The game goes back to its own database.

## 7. If something goes wrong

- **Nothing changed in the game:** ModKit isn't installed, or the mod's files went into a folder of their own -
  `BepInEx\plugins\EMSkin.dll` must be in the game's folder, next to `EsportsManager.exe`'s `BepInEx` folder.
- **The black console window bothers you:** it is ModKit's. Open `BepInEx\config\BepInEx.cfg` with Notepad, and under
  `[Logging.Console]` set `Enabled = false`.
- **After a Steam update** of the game the mod (or ModKit) may stop working until it is updated too.
- **Anything else:** ask in the mod's Discord, https://discord.gg/PcXxHFB8zR - `/bug` there reports a bug; send the
  file `BepInEx\LogOutput.log` from the game's folder with it.

## 8. Support the mod

The mod is free. If you enjoy it and want to support its development, you can donate on Boosty or in crypto. Thank you!

- **Boosty:** https://boosty.to/iamgrimod/donate
- **EVM** (Ethereum, BNB Chain and other EVM networks): `0x58858d8c7580eb918494accf359a0a8deaa865f2`
- **Solana:** `8GG8D5dxWfvcscJXJWsbjUok4jgzXsUBxs69ip98DHGq`
- **TRON (TRC20):** `TLjEpSrAPdVco88aT5TUBtVhdGWAVP76wk`

Send crypto only on the network shown for the address - a transfer on another network is lost.
